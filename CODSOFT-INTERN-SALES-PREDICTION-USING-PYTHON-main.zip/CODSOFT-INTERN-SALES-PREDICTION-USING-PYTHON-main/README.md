# CODSOFT-INTERN-SALES-PREDICTION-USING-PYTHON
Sales prediction involves forecasting the amount of a product that customers will purchase, taking into account various factors such as advertising expenditure, target audience segmentation, and advertising platform selection.
